export { cloudifyPlugin, CloudifyPage } from './plugin';
