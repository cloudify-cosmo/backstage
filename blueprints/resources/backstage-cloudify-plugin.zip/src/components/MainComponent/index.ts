export { MainComponent } from './MainComponent';
