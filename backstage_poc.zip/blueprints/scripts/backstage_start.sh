#!/usr/bin/env bash


set -e

sudo systemctl start backstagebackend
sudo systemctl start backstagefrontend
